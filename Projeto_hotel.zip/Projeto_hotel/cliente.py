class Cliente():
    def __init__(self, nome_do_cliente:str, telefone_do_cliente:str, email_do_cliente:str, id_do_cliente:int):
        self.nome_do_cliente = nome_do_cliente
        self.telefone_do_cliente = telefone_do_cliente
        self.email_do_cliente = email_do_cliente
        self.__id_do_cliente = id_do_cliente
    
    def getId(self):
        return self.__id_do_cliente