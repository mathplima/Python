from cliente import Cliente
from quarto import Quarto
from reserva import Reserva

class Hotel():
    def __init__(self, nome_do_hotel:str, cnpj_do_hotel:str, endereco_do_hotel:str):
        self.nome_do_hotel = nome_do_hotel
        self.cnpj_do_hotel = cnpj_do_hotel
        self.endereco_do_hotel = endereco_do_hotel
        self.lista_de_clientes = []
        self.lista_de_quartos = []
        self.lista_de_reservas = []
        self.contador_de_clientes = 100
    

    def cadastrar_cliente(self):
        nome_cliente = input("Nome do Cliente: ")
        telefone_cliente = input("Telefone do Cliente: ")
        email_cliente = input("Email do Cliente: ")

        novoCliente = Cliente(
            nome_do_cliente=nome_cliente,
            telefone_do_cliente=telefone_cliente,
            email_do_cliente=email_cliente,
            id_do_cliente=self.contador_de_clientes
        )
        self.contador_de_clientes += 1
        self.lista_de_clientes.append(novoCliente)
        return f"Cliente {nome_cliente} cadastrado com sucesso!"
    
    def verLista_de_clientes(self):
        for element in self.lista_de_clientes:
            print(f"""
            ---Clientes do Hotel---
            Cliente: {element.nome_cliente}
            Telefone: {element.telefone_cliente}
            Email: {element.email_cliente}
            ID: {element.id_do_clientes}
            ----------------------------
        """)
    
    def excluir_cliente(self):
        nome_excluir_cliente = input("Informe o nome do Cliente para excluir")
        nome_encontrado = 0
        for element in self.lista_de_clientes:
            if element.nome_cliente == nome_excluir_cliente:
                nome_encontrado += 1
                self.lista_de_clientes.remove(element)
                return f"Cliente excluído com sucesso!"
    

    def cadastrar_quarto(self):
        numero_novo_quarto = input("Numero do Novo Quarto: ")
        tipo_novo_quarto = input("Tipo do Novo Quarto: ")
        preco_novo_quarto = input("Valor do Novo Quarto: ")

        novo_quarto = Quarto(
            numero_do_quarto=numero_novo_quarto,
            tipo_do_quarto=tipo_novo_quarto,
            preco_do_quarto=preco_novo_quarto,
            disponibilidade=True
        )
        self.lista_de_quartos.append(novo_quarto)
        return f"Quarto cadastrado com sucesso!"
    
    def verLista_de_quartos(self):
        for element in self.lista_de_quartos:
            print(f"""
            ---Quartos do Hotel---
            Quarto: {element.numero_novo_quarto}
            Tipo: {element.tipo_novo_quarto}
            Preço: R$ {element.preco_novo_quarto}
            Disponibilidade: {element.disponibilidade_novo_quarto}
            -----------------------
""")
    
    def excluir_quarto(self):
        numero_excluir_quarto = input("Numero do quarto que deseja excluir: ")
        numero_encontrado = 0
        for element in self.lista_de_quartos:
            if element.numero_novo_quarto == numero_excluir_quarto:
                numero_encontrado += 1
                self.lista_de_quartos.remove(element)
                return f"Quarto excluído com sucesso!"
    

    def cadastrar_reserva(self):
        nome_dono_reserva = input("Nome do Reservante: ")
        quarto_da_reserva = input("Numero do Quarto que deseja reservar: ")
        checkin_da_reserva = input("Data do Check-in da reserva: ")
        checkout_da_reserva = input("Data do Check-out da reserva: ")

        quarto_encontrado = None 
        for element in self.lista_de_quartos:
            if element.numero_do_quarto == quarto_da_reserva:
                quarto_encontrado = element.numero_do_quarto
                break
        
        if quarto_encontrado is None:
            return f"Erro: Quarto não encontrado."
        if not quarto_encontrado.disponibilidade:
            return f"Erro: Quarto indisponivel."
        
        nova_reserva = Reserva(
            dono_da_reserva=nome_dono_reserva,
            quarto_reservado=quarto_da_reserva,
            data_check_in=checkin_da_reserva,
            data_check_out=checkout_da_reserva,
            status_da_reserva="Reservado"
        )
        self.lista_de_reservas.append(nova_reserva)
        quarto_encontrado.disponibilidade = False
        return f"Reserva cadastrada com sucesso!"
    
    def verQuartos_reservados(self):
        for element in self.lista_de_reservas:
            print(f"""
            ---Quartos Reservados---
            Dono da Reserva: {element.nome_dono_reserva}
            Quarto da Reserva: {element.quarto_da_reserva}
            Check-in da Reserva: {element.checkin_da_reserva}
            Check-out da Reserva: {element.checkout_da_reserva}
            Status da Reserva: Reservado
            -------------------------
""")


