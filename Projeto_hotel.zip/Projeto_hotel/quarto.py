class Quarto():
    def __init__(self, numero_do_quarto:int, tipo_do_quarto:str, preco_do_quarto:float, disponibilidade=True):
        self.numero_do_quarto = numero_do_quarto
        self.tipo_do_quarto = tipo_do_quarto
        self.preco_do_quarto = preco_do_quarto
        self.disponibilidade = disponibilidade