from quarto import Quarto

class Reserva():
    def __init__(self, dono_da_reserva:str, quarto_reservado:Quarto, data_check_in:str, data_check_out:str, status_da_reserva:str):
        self.dono_da_reserva = dono_da_reserva
        self.quarto_reservado = quarto_reservado
        self.data_check_in = data_check_in
        self.data_check_out = data_check_out
        self.status_da_reserva = status_da_reserva